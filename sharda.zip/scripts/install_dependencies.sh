#!/bin/bash
apt-get install -y nginx